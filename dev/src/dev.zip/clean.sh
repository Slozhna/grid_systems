#! /bin/bash

rm !($0)
