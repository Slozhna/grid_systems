#! /bin/bash
mpicc *.c -o $1
